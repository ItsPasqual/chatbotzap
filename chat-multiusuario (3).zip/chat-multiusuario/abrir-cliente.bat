@echo off
rem Cada duplo clique abre uma janela de chat nova (um usuario por janela).
rem Outra maquina: abrir-cliente.bat IP_DO_SERVIDOR
chcp 65001 >nul
if "%~1"=="" (
  start "" cmd /c mvn -q compile exec:java "-Dexec.mainClass=client.ClienteChatGui"
) else (
  start "" cmd /c mvn -q compile exec:java "-Dexec.mainClass=client.ClienteChatGui" "-Dexec.args=%~1 5000"
)
