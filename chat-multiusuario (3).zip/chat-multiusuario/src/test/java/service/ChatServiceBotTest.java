package service;

import model.Mensagem;
import model.Usuario;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import service.bot.Bot;
import service.bot.BotProjeto;
import support.FakeConexao;
import support.InMemoryMensagemRepository;

import java.time.Clock;
import java.time.Instant;
import java.time.ZoneId;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

class ChatServiceBotTest {

    private InMemoryMensagemRepository repository;
    private ClientRegistry registry;
    private ChatService service;
    private final Usuario ana = new Usuario("ana");
    private final Clock relogio = Clock.fixed(Instant.parse("2026-10-06T21:15:00Z"), ZoneId.of("UTC"));

    @BeforeEach
    void preparar() {
        repository = new InMemoryMensagemRepository();
        registry = new ClientRegistry();
        service = new ChatService(repository, registry, relogio, 10, new BotProjeto());
    }

    @Test
    void botResponderEhSalvoETransmitidoATodos() {
        FakeConexao a = new FakeConexao("ana");
        FakeConexao b = new FakeConexao("bruno");
        service.conectar(a);
        service.conectar(b);

        service.enviarMensagem(ana, "@bot como funciona a concorrência?");

        assertEquals(2, repository.total()); // pergunta + resposta
        for (FakeConexao f : new FakeConexao[]{a, b}) {
            assertTrue(f.recebidas().stream().anyMatch(l -> l.contains("] ChatBot: @ana Uma thread por cliente")));
        }
    }

    @Test
    void respostaDoBotVemDepoisDaPergunta() {
        FakeConexao a = new FakeConexao("ana");
        service.conectar(a);
        service.enviarMensagem(ana, "@bot ajuda");

        var linhas = a.recebidas();
        int pergunta = -1;
        int resposta = -1;
        for (int i = 0; i < linhas.size(); i++) {
            if (linhas.get(i).contains("ana: @bot ajuda")) {
                pergunta = i;
            }
            if (linhas.get(i).contains("ChatBot: @ana Pergunte sobre")) {
                resposta = i;
            }
        }
        assertTrue(pergunta >= 0 && resposta == pergunta + 1);
    }

    @Test
    void nomeDoBotEhReservado() {
        assertThrows(NicknameEmUsoException.class, () -> service.conectar(new FakeConexao("chatbot")));
        assertEquals(0, registry.quantidade());
    }

    @Test
    void boasVindasDoBotVaoSoParaQuemEntrouENaoSaoPersistidas() {
        FakeConexao a = new FakeConexao("ana");
        service.conectar(a);
        FakeConexao b = new FakeConexao("bruno");
        service.conectar(b);

        assertTrue(b.recebidas().stream().anyMatch(l -> l.contains("ChatBot: Oi, bruno!")));
        assertFalse(a.recebidas().stream().anyMatch(l -> l.contains("Oi, bruno!")));
        assertEquals(0, repository.total());
    }

    @Test
    void falhaNoBotNaoDerrubaOChat() {
        Bot quebrado = new Bot() {
            public Usuario getUsuario() { return new Usuario("Quebrado"); }
            public Optional<String> responder(Usuario autor, String texto) { throw new IllegalStateException("boom"); }
            public String boasVindas(Usuario novo) { return "oi"; }
        };
        ChatService s = new ChatService(repository, registry, relogio, 10, quebrado);
        FakeConexao a = new FakeConexao("ana");
        s.conectar(a);

        Mensagem salva = s.enviarMensagem(ana, "olá");

        assertEquals("olá", salva.getConteudo());
        assertTrue(a.recebidas().stream().anyMatch(l -> l.contains("ana: olá")));
    }

    @Test
    void botLentoNaoTravaOChat() throws Exception {
        var iniciou = new java.util.concurrent.CountDownLatch(1);
        var liberar = new java.util.concurrent.CountDownLatch(1);
        Bot lento = new Bot() {
            public Usuario getUsuario() { return BotProjeto.USUARIO; }
            public Optional<String> responder(Usuario autor, String texto) {
                iniciou.countDown();
                try { liberar.await(); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
                return Optional.of("pronto");
            }
            public String boasVindas(Usuario novo) { return "oi"; }
        };
        var pool = java.util.concurrent.Executors.newSingleThreadExecutor();
        try {
            ChatService s = new ChatService(repository, registry, relogio, 10, lento, pool);
            FakeConexao a = new FakeConexao("ana");
            s.conectar(a);

            s.enviarMensagem(ana, "@bot pergunta demorada");
            assertTrue(iniciou.await(2, java.util.concurrent.TimeUnit.SECONDS));

            // com o bot ainda "pensando", outra mensagem passa na hora
            s.enviarMensagem(new Usuario("bruno"), "oi pessoal");
            assertTrue(a.recebidas().stream().anyMatch(l -> l.contains("bruno: oi pessoal")));
            assertFalse(a.recebidas().stream().anyMatch(l -> l.contains("ChatBot: @ana pronto")));

            liberar.countDown();
            pool.shutdown();
            assertTrue(pool.awaitTermination(2, java.util.concurrent.TimeUnit.SECONDS));
            assertTrue(a.recebidas().stream().anyMatch(l -> l.contains("ChatBot: @ana pronto")));
        } finally {
            liberar.countDown();
            pool.shutdownNow();
        }
    }

    // ------------------------------------------------------------ resposta direcionada

    @Test
    void respostaDoBotCitaQuemPerguntou() {
        FakeConexao a = new FakeConexao("ana");
        FakeConexao b = new FakeConexao("bruno");
        service.conectar(a);
        service.conectar(b);

        service.enviarMensagem(new Usuario("bruno"), "@bot ajuda");

        assertTrue(a.recebidas().stream().anyMatch(l -> l.contains("] ChatBot: @bruno Pergunte sobre")));
        assertTrue(repository.buscarUltimas(100).stream()
                .anyMatch(m -> m.getRemetente().equals(BotProjeto.USUARIO) && m.getConteudo().startsWith("@bruno ")));
    }

    @Test
    void direcionarCortaRespostaQueEstourariaOLimite() {
        String longa = "x".repeat(Mensagem.TAMANHO_MAXIMO);

        String r = ChatService.direcionar(new Usuario("ana"), longa);

        assertEquals(Mensagem.TAMANHO_MAXIMO, r.length());
        assertTrue(r.startsWith("@ana x"));
        assertTrue(r.endsWith("…"));
        assertEquals("@ana oi", ChatService.direcionar(new Usuario("ana"), "oi"));
    }

    // ------------------------------------------------------------ sugestões dinâmicas

    @Test
    void sugestoesVaoSoParaQuemPerguntou() {
        FakeConexao a = new FakeConexao("ana");
        FakeConexao b = new FakeConexao("bruno");
        service.conectar(a);
        service.conectar(b);

        service.enviarMensagem(ana, "@bot como funciona a concorrência?");

        String linha = a.recebidas().stream().filter(l -> l.startsWith("#sugestoes ")).findFirst().orElseThrow();
        assertTrue(linha.contains("Race conditions;@bot race conditions;1"));
        assertTrue(b.recebidas().stream().noneMatch(l -> l.startsWith("#sugestoes")));
    }

    @Test
    void semTopicoReconhecidoNaoMandaSugestoes() {
        FakeConexao a = new FakeConexao("ana");
        service.conectar(a);

        service.enviarMensagem(ana, "@bot blablabla"); // BotProjeto responde "Não entendi", sem tópico

        assertTrue(a.recebidas().stream().noneMatch(l -> l.startsWith("#sugestoes")));
    }

    // ------------------------------------------------------------ "ChatBot está digitando…"

    /** Bot controlável: demora() sempre true; cada resposta espera o seu latch. */
    private static class BotManual implements Bot {
        final java.util.concurrent.CountDownLatch liberar = new java.util.concurrent.CountDownLatch(1);
        final java.util.concurrent.CountDownLatch iniciou = new java.util.concurrent.CountDownLatch(1);
        volatile boolean falhar;

        public Usuario getUsuario() { return BotProjeto.USUARIO; }
        public boolean demora(String texto) { return true; }
        public Optional<String> responder(Usuario autor, String texto) {
            iniciou.countDown();
            try { liberar.await(); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
            if (falhar) { throw new IllegalStateException("boom"); }
            return Optional.of("pronto");
        }
        public String boasVindas(Usuario novo) { return "oi"; }
    }

    @Test
    void digitandoApareceParaTodosEPassaDepoisDaResposta() throws Exception {
        BotManual manual = new BotManual();
        var pool = java.util.concurrent.Executors.newSingleThreadExecutor();
        try {
            ChatService s = new ChatService(repository, registry, relogio, 10, manual, pool);
            FakeConexao a = new FakeConexao("ana");
            FakeConexao b = new FakeConexao("bruno");
            s.conectar(a);
            s.conectar(b);

            s.enviarMensagem(ana, "@bot pergunta demorada");
            assertTrue(manual.iniciou.await(2, java.util.concurrent.TimeUnit.SECONDS));
            for (FakeConexao f : new FakeConexao[]{a, b}) {
                assertTrue(f.recebidas().contains("#digitando ChatBot"));
                assertFalse(f.recebidas().contains("#parou ChatBot"));
            }

            manual.liberar.countDown();
            pool.shutdown();
            assertTrue(pool.awaitTermination(2, java.util.concurrent.TimeUnit.SECONDS));

            var linhas = a.recebidas();
            assertTrue(linhas.indexOf("#digitando ChatBot") < indiceDe(linhas, "ChatBot: @ana pronto"));
            assertTrue(indiceDe(linhas, "ChatBot: @ana pronto") < linhas.indexOf("#parou ChatBot"));
        } finally {
            manual.liberar.countDown();
            pool.shutdownNow();
        }
    }

    @Test
    void indicadorSomeMesmoQuandoOBotFalha() throws Exception {
        BotManual manual = new BotManual();
        manual.falhar = true;
        manual.liberar.countDown();
        FakeConexao a = new FakeConexao("ana");
        ChatService s = new ChatService(repository, registry, relogio, 10, manual); // executor direto
        s.conectar(a);

        s.enviarMensagem(ana, "@bot qualquer coisa");

        assertTrue(a.recebidas().contains("#digitando ChatBot"));
        assertTrue(a.recebidas().contains("#parou ChatBot"));
        assertTrue(a.recebidas().stream().noneMatch(l -> l.contains("ChatBot: @ana")));
    }

    @Test
    void duasPerguntasSimultaneasSoApagamOIndicadorQuandoAUltimaTermina() throws Exception {
        var primeira = new java.util.concurrent.CountDownLatch(1);
        var segunda = new java.util.concurrent.CountDownLatch(1);
        var chamadas = new java.util.concurrent.atomic.AtomicInteger();
        Bot bot = new Bot() {
            public Usuario getUsuario() { return BotProjeto.USUARIO; }
            public boolean demora(String texto) { return true; }
            public Optional<String> responder(Usuario autor, String texto) {
                var meu = chamadas.incrementAndGet() == 1 ? primeira : segunda;
                try { meu.await(); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
                return Optional.of("resposta de " + autor.nome());
            }
            public String boasVindas(Usuario novo) { return "oi"; }
        };
        var pool = java.util.concurrent.Executors.newFixedThreadPool(2);
        try {
            ChatService s = new ChatService(repository, registry, relogio, 10, bot, pool);
            FakeConexao a = new FakeConexao("ana");
            s.conectar(a);
            s.enviarMensagem(new Usuario("ana"), "@bot um");
            s.enviarMensagem(new Usuario("bruno"), "@bot dois");
            while (chamadas.get() < 2) { Thread.sleep(10); }

            primeira.countDown();
            esperar(() -> a.recebidas().stream().anyMatch(l -> l.contains("ChatBot: @ana resposta de ana")));
            assertFalse(a.recebidas().contains("#parou ChatBot")); // a segunda ainda está pensando

            segunda.countDown();
            esperar(() -> a.recebidas().contains("#parou ChatBot"));
            assertEquals(1L, a.recebidas().stream().filter(l -> l.equals("#parou ChatBot")).count());
        } finally {
            primeira.countDown();
            segunda.countDown();
            pool.shutdownNow();
        }
    }

    @Test
    void botRapidoNaoMostraDigitando() {
        FakeConexao a = new FakeConexao("ana");
        service.conectar(a); // BotProjeto responde na hora

        service.enviarMensagem(ana, "@bot ajuda");

        assertTrue(a.recebidas().stream().noneMatch(l -> l.startsWith("#digitando") || l.startsWith("#parou")));
    }

    private static int indiceDe(java.util.List<String> linhas, String trecho) {
        for (int i = 0; i < linhas.size(); i++) {
            if (linhas.get(i).contains(trecho)) {
                return i;
            }
        }
        return -1;
    }

    private static void esperar(java.util.function.BooleanSupplier condicao) throws InterruptedException {
        long limite = System.currentTimeMillis() + 2000;
        while (!condicao.getAsBoolean() && System.currentTimeMillis() < limite) {
            Thread.sleep(10);
        }
        assertTrue(condicao.getAsBoolean(), "condição não ocorreu a tempo");
    }
}
