package service.bot;

import model.Usuario;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

class BotProjetoTest {

    private final BotProjeto bot = new BotProjeto();
    private final Usuario ana = new Usuario("ana");

    @Test
    void respondeSobreRequisitos() {
        String r = bot.responder(ana, "@bot quais são os requisitos?").orElseThrow();
        assertTrue(r.contains("ServerSocket"));
    }

    @Test
    void respondeSobreConcorrenciaComOuSemAcento() {
        assertTrue(bot.responder(ana, "como funciona a concorrência?").orElseThrow().contains("thread"));
        assertTrue(bot.responder(ana, "COMO FUNCIONA A CONCORRENCIA").orElseThrow().contains("thread"));
    }

    @Test
    void ignoraConversaSemRelacaoComOProjeto() {
        assertFalse(bot.responder(ana, "vamos almoçar?").isPresent());
    }

    @Test
    void saudaPeloNome() {
        assertTrue(bot.responder(ana, "oi").orElseThrow().startsWith("Oi, ana!"));
    }

    @Test
    void quandoChamadoSemEntenderMostraAjuda() {
        assertTrue(bot.responder(ana, "@bot blablabla").orElseThrow().startsWith("Não entendi"));
    }

    @Test
    void naoRespondeAElePropriio() {
        assertFalse(bot.responder(BotProjeto.USUARIO, "requisitos").isPresent());
    }

    @Test
    void todasAsRespostasCabemEmUmaMensagemDeUmaLinha() {
        for (String pergunta : new String[]{"requisitos", "arquitetura", "concorrência", "race", "broadcast",
                "banco", "testes", "protocolo", "desconexão", "nickname", "critérios", "cronograma",
                "relatório", "extras", "ajuda", "você"}) {
            String r = bot.responder(ana, pergunta).orElseThrow();
            assertTrue(r.length() <= model.Mensagem.TAMANHO_MAXIMO, pergunta + " tem " + r.length());
            assertFalse(r.contains("\n"), pergunta);
        }
        assertEquals(true, bot.boasVindas(ana).length() < 500);
    }

    @Test
    void sugestoesSaoDoMesmoAssuntoENuncaDevolvemOProprioTopico() {
        var sugestoes = bot.sugestoes("como funciona a concorrência?");

        assertFalse(sugestoes.isEmpty());
        assertTrue(sugestoes.size() <= Sugestao.MAXIMO_POR_LINHA);
        assertTrue(sugestoes.stream().anyMatch(s -> s.rotulo().equals("Race conditions")));
        assertTrue(sugestoes.stream().noneMatch(s -> s.rotulo().equals("Concorrência")));
    }

    @Test
    void todaSugestaoDoBotLevaARespostaDeUmTopicoReal() {
        for (String pergunta : new String[]{"requisitos", "arquitetura", "concorrência", "race conditions",
                "broadcast", "banco de dados", "testes", "protocolo", "desconexão", "nickname", "critérios",
                "relatório", "cronograma", "extras", "ajuda", "quem é você"}) {
            for (Sugestao s : bot.sugestoes(pergunta)) {
                String r = bot.responder(ana, s.texto()).orElseThrow();
                assertFalse(r.startsWith("Não entendi"), "sugestão sem resposta: " + s.texto());
            }
        }
    }

    @Test
    void semTopicoNaoHaSugestoes() {
        assertTrue(bot.sugestoes("vamos almoçar?").isEmpty());
        assertTrue(bot.sugestoes(null).isEmpty());
    }

    @Test
    void sugestoesViramLinhaDeProtocoloSemSeparadoresNosCampos() {
        String linha = Sugestao.serializar(java.util.List.of(
                Sugestao.enviar("a|b", "@bot x;y"), Sugestao.completar("O que é…?", "@bot o que é ")));

        assertEquals("a b;@bot x y;1|O que é…?;@bot o que é ;0", linha);
    }
}
