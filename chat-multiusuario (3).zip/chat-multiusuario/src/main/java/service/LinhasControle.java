package service;

import service.bot.Sugestao;

import java.util.List;

/**
 * Linhas de CONTROLE do protocolo: começam com '#' e não são mensagens de chat. O cliente gráfico as
 * interpreta (indicador "digitando…" e botões de sugestão); o cliente de console as ignora.
 *
 * Nunca colidem com texto de usuário: mensagens de chat chegam como "[dd/MM HH:mm] nick: ..." e
 * avisos do sistema começam com "* ". Controle não é salvo no banco nem entra no histórico.
 *
 *   #digitando ChatBot             o bot começou a preparar uma resposta demorada
 *   #parou ChatBot                 o bot terminou (respondeu ou desistiu)
 *   #sugestoes rotulo;texto;1|...  novos botões só para quem perguntou (1 = envia, 0 = só preenche)
 */
public final class LinhasControle {

    public static final String PREFIXO = "#";

    private LinhasControle() {
    }

    public static String digitando(String nome) {
        return PREFIXO + "digitando " + nome;
    }

    public static String parou(String nome) {
        return PREFIXO + "parou " + nome;
    }

    public static String sugestoes(List<Sugestao> sugestoes) {
        return PREFIXO + "sugestoes " + Sugestao.serializar(sugestoes);
    }
}
