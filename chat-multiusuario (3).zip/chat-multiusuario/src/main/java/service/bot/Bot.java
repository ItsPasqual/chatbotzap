package service.bot;

import model.Usuario;

import java.text.Normalizer;
import java.util.List;
import java.util.Optional;

/** Participante automático do chat. Não conhece rede nem banco. */
public interface Bot {

    Usuario getUsuario();

    /** Resposta (uma única linha, até 500 caracteres) ou vazio se não tiver o que dizer. */
    Optional<String> responder(Usuario autor, String texto);

    /** Mensagem enviada apenas a quem acabou de entrar (não é salva no banco). */
    String boasVindas(Usuario novo);

    /**
     * true se responder a este texto provavelmente vai demorar (rede, IA). O ChatService usa isso
     * para mostrar "ChatBot está digitando…". Respostas instantâneas devolvem false.
     */
    default boolean demora(String texto) {
        return false;
    }

    /** Botões de sugestão para quem fez esta pergunta (vazio = não muda os botões atuais). */
    default List<Sugestao> sugestoes(String pergunta) {
        return List.of();
    }

    /** O texto chama o bot com "@bot" ou "@chatbot" (sem distinguir acentos nem maiúsculas)? */
    static boolean mencionaBot(String texto) {
        if (texto == null) {
            return false;
        }
        String t = Normalizer.normalize(texto, Normalizer.Form.NFD).replaceAll("\\p{M}", "").toLowerCase();
        return t.contains("@bot") || t.contains("@chatbot");
    }
}
