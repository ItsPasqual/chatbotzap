package service.bot;

import java.util.List;
import java.util.stream.Collectors;

/**
 * Botão de sugestão rápida exibido pelo cliente.
 *
 * @param rotulo texto curto do botão
 * @param texto  o que vai para o chat (ou para o campo de digitação)
 * @param enviar true = envia na hora; false = só preenche o campo para a pessoa completar
 */
public record Sugestao(String rotulo, String texto, boolean enviar) {

    public static final int MAXIMO_POR_LINHA = 5;

    /** Sugestões iniciais (as mesmas que o cliente mostra antes de qualquer resposta do bot). */
    public static List<Sugestao> padrao() {
        return List.of(
                enviar("Ajuda", "@bot ajuda"),
                enviar("Que horas?", "@bot que horas são?"),
                enviar("Conta", "@bot 12 * (3 + 4)"),
                completar("O que é…?", "@bot o que é "),
                enviar("Projeto", "@bot como funciona a concorrência?"));
    }

    public static Sugestao enviar(String rotulo, String texto) {
        return new Sugestao(rotulo, texto, true);
    }

    public static Sugestao completar(String rotulo, String texto) {
        return new Sugestao(rotulo, texto, false);
    }

    /** Formato da linha de protocolo: "rotulo;texto;1|rotulo;texto;0" (separadores removidos dos campos). */
    public static String serializar(List<Sugestao> sugestoes) {
        return sugestoes.stream()
                .limit(MAXIMO_POR_LINHA)
                .map(s -> limpar(s.rotulo()) + ";" + limpar(s.texto()) + ";" + (s.enviar() ? "1" : "0"))
                .collect(Collectors.joining("|"));
    }

    private static String limpar(String campo) {
        return campo.replace('|', ' ').replace(';', ' ').replace('\n', ' ').replace('\r', ' ');
    }
}
