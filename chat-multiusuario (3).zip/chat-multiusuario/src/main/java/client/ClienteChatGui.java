package client;

import javax.swing.BorderFactory;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.ScrollPaneConstants;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import javax.swing.WindowConstants;
import javax.swing.border.EmptyBorder;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Cliente com janela no estilo WhatsApp (Swing). Só conhece a rede (mesmo protocolo do ClienteChat).
 * A thread de rede NUNCA mexe nos componentes: tudo passa por SwingUtilities.invokeLater.
 * Uso: ClienteChatGui [host] [porta]
 */
public class ClienteChatGui {

    static final String NOME_BOT = "ChatBot";
    private static final Pattern MENSAGEM = Pattern.compile("^\\[(\\d{2}/\\d{2}) (\\d{2}:\\d{2})] (\\S+): (.*)$");

    private record Sugestao(String rotulo, String texto, boolean enviar) {
    }

    private static final List<Sugestao> SUGESTOES_INICIAIS = List.of(
            new Sugestao("Ajuda", "@bot ajuda", true),
            new Sugestao("Que horas?", "@bot que horas são?", true),
            new Sugestao("Conta", "@bot 12 * (3 + 4)", true),
            new Sugestao("O que é…?", "@bot o que é ", false),
            new Sugestao("Projeto", "@bot como funciona a concorrência?", true));

    private final String host;
    private final int porta;
    private TemaChat tema = TemaChat.ESCURO;
    private String nickAtual = "";

    private JFrame janela;
    private JPanel cabecalho;
    private JPanel sul;
    private JPanel painelSugestoes;
    private JPanel barraEntrada;
    private JLabel titulo;
    private JLabel subtitulo;
    private Widgets.Avatar avatar;
    private Widgets.BotaoIcone botaoTema;
    private Widgets.BotaoIcone botaoEnviar;
    private Widgets.CampoArredondado campo;
    private ConversaPanel conversa;
    private JScrollPane rolagem;
    private final List<Widgets.Pilula> pilulas = new ArrayList<>();

    // indicador "ChatBot está digitando…"
    private static final int LIMITE_DIGITANDO_MS = 60_000; // segurança caso o "#parou" se perca
    private javax.swing.Timer relogioDigitando;
    private String quemDigita;
    private long digitandoDesde;
    private int pontos;

    private Socket socket;
    private PrintWriter saida;
    private volatile boolean encerrado;

    public ClienteChatGui(String host, int porta) {
        this.host = host;
        this.porta = porta;
    }

    public static void main(String[] args) {
        String host = args.length > 0 ? args[0] : "localhost";
        int porta = args.length > 1 ? Integer.parseInt(args[1]) : 5000;
        SwingUtilities.invokeLater(() -> new ClienteChatGui(host, porta).iniciar());
    }

    // ------------------------------------------------------------ montagem da janela

    private void iniciar() {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception e) {
            // segue com o visual padrão
        }
        janela = new JFrame("Chat Multiusuário");
        janela.setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
        janela.setContentPane(construirConteudo());
        janela.setSize(480, 720);
        janela.setMinimumSize(new Dimension(450, 520));
        janela.setLocationByPlatform(true);
        janela.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                sair();
            }
        });

        String nickname = TelaEntrada.pedir(null, null);
        if (nickname == null) {
            System.exit(0);
        }
        try {
            conectar(nickname);
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null,
                    "Não foi possível conectar a " + host + ":" + porta
                            + "\nO servidor está rodando?\n(abra server/Servidor.java e clique em Run antes)\n\n"
                            + e.getMessage(),
                    "Erro de conexão", JOptionPane.ERROR_MESSAGE);
            System.exit(1);
        }
        janela.setVisible(true);
        campo.requestFocusInWindow();
        rolarParaOFim();
    }

    /** Monta todo o conteúdo da janela (separado de JFrame para poder ser desenhado em testes). */
    JPanel construirConteudo() {
        // cabeçalho: avatar + nome do chat + botão de tema
        avatar = new Widgets.Avatar();
        titulo = new JLabel("Chat Multiusuário");
        titulo.setFont(Fontes.de(Font.BOLD, 16));
        subtitulo = new JLabel("conectando...");
        subtitulo.setFont(Fontes.de(Font.PLAIN, 12));
        JPanel textos = new JPanel(new GridLayout(2, 1, 0, 1));
        textos.setOpaque(false);
        textos.add(titulo);
        textos.add(subtitulo);

        botaoTema = new Widgets.BotaoIcone(Widgets.Icone.SOL, 38);
        botaoTema.setToolTipText("Alternar tema claro/escuro");
        botaoTema.addActionListener(e -> {
            tema = tema.escuro() ? TemaChat.CLARO : TemaChat.ESCURO;
            aplicarTema();
        });

        cabecalho = new JPanel(new BorderLayout(12, 0));
        cabecalho.setBorder(new EmptyBorder(10, 14, 10, 12));
        cabecalho.add(avatar, BorderLayout.WEST);
        cabecalho.add(textos, BorderLayout.CENTER);
        cabecalho.add(botaoTema, BorderLayout.EAST);

        // conversa
        conversa = new ConversaPanel();
        rolagem = new JScrollPane(conversa, ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
                ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        rolagem.setBorder(null);
        rolagem.setViewportBorder(null);
        rolagem.getViewport().setScrollMode(javax.swing.JViewport.SIMPLE_SCROLL_MODE); // papel de parede fixo

        // sugestões rápidas para o bot
        painelSugestoes = new JPanel(new Widgets.WrapLayout(FlowLayout.LEFT, 6, 4));
        painelSugestoes.setBorder(new EmptyBorder(4, 8, 0, 8));
        montarPilulas(SUGESTOES_INICIAIS);

        // barra de digitação
        campo = new Widgets.CampoArredondado("Digite uma mensagem");
        campo.addActionListener(e -> enviar());
        botaoEnviar = new Widgets.BotaoIcone(Widgets.Icone.ENVIAR, 46);
        botaoEnviar.setToolTipText("Enviar");
        botaoEnviar.addActionListener(e -> enviar());
        barraEntrada = new JPanel(new BorderLayout(8, 0));
        barraEntrada.setBorder(new EmptyBorder(6, 10, 12, 10));
        barraEntrada.add(campo, BorderLayout.CENTER);
        barraEntrada.add(botaoEnviar, BorderLayout.EAST);

        sul = new JPanel(new BorderLayout());
        sul.add(painelSugestoes, BorderLayout.NORTH);
        sul.add(barraEntrada, BorderLayout.CENTER);

        JPanel raiz = new JPanel(new BorderLayout());
        raiz.add(cabecalho, BorderLayout.NORTH);
        raiz.add(rolagem, BorderLayout.CENTER);
        raiz.add(sul, BorderLayout.SOUTH);
        aplicarTema();
        return raiz;
    }

    private void aplicarTema() {
        TemaChat t = tema;
        cabecalho.setBackground(t.cabecalho());
        titulo.setForeground(t.textoCabecalho());
        subtitulo.setForeground(corDoSubtitulo());
        avatar.fundo = t.avatarFundo();
        avatar.icone = t.avatarIcone();
        botaoTema.icone = t.escuro() ? Widgets.Icone.SOL : Widgets.Icone.LUA;
        botaoTema.frente = t.textoCabecalho();

        conversa.setTema(t);
        rolagem.getViewport().setBackground(t.fundo());
        Widgets.ScrollFino.aplicar(rolagem.getVerticalScrollBar(),
                t.escuro() ? new Color(255, 255, 255, 70) : new Color(0, 0, 0, 70));

        sul.setBackground(t.rodape());
        painelSugestoes.setBackground(t.rodape());
        barraEntrada.setBackground(t.rodape());
        aplicarCoresDasPilulas();
        campo.fundoCampo = t.campo();
        campo.corDica = t.dica();
        campo.setForeground(t.textoCampo());
        campo.setCaretColor(t.textoCampo());
        botaoEnviar.fundo = t.enviar();
        botaoEnviar.frente = Color.WHITE;
        cabecalho.repaint();
        sul.repaint();
        conversa.repaint();
    }

    // ------------------------------------------------------------ rede

    private void conectar(String nickname) throws IOException {
        definirNick(nickname);
        socket = new Socket(host, porta);
        BufferedReader doServidor = new BufferedReader(
                new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8));
        saida = new PrintWriter(new OutputStreamWriter(socket.getOutputStream(), StandardCharsets.UTF_8), true);
        saida.println(nickname);

        Thread leitor = new Thread(() -> {
            try {
                String linha;
                while ((linha = doServidor.readLine()) != null) {
                    String recebida = linha;
                    SwingUtilities.invokeLater(() -> tratarLinha(recebida));
                }
            } catch (IOException e) {
                // conexão encerrada
            }
            SwingUtilities.invokeLater(this::conexaoEncerrada);
        }, "leitor-socket");
        leitor.setDaemon(true);
        leitor.start();
    }

    private void definirNick(String nick) {
        nickAtual = nick;
        conversa.setNick(nick);
    }

    /** Executa na thread do Swing. */
    void tratarLinha(String linha) {
        if (linha.startsWith("#")) {
            tratarControle(linha);
            return;
        }
        if (linha.startsWith("* Bem-vindo")) {
            return; // o nickname já foi enviado
        }
        if (linha.endsWith("Tente outro nickname:")) {
            adicionar(linha);
            String novo = TelaEntrada.pedir(janela, linha.substring(2));
            if (novo == null) {
                sair();
            } else {
                definirNick(novo);
                saida.println(novo);
            }
        } else if (linha.startsWith("* Digite suas mensagens")) {
            if (janela != null) {
                janela.setTitle("Chat Multiusuário - " + nickAtual);
            }
            subtitulo.setText("online como " + nickAtual);
            rolarParaOFim();
        } else {
            adicionar(linha);
        }
    }

    /** Põe a linha do protocolo na conversa; rola para o fim se o usuário já estava lá embaixo. */
    void adicionar(String linha) {
        JScrollBar barra = rolagem.getVerticalScrollBar();
        boolean noFim = barra.getValue() + barra.getVisibleAmount() >= barra.getMaximum() - 80;
        boolean propria = false;

        Matcher m = MENSAGEM.matcher(linha);
        if (m.matches()) {
            propria = m.group(3).equalsIgnoreCase(nickAtual);
            conversa.adicionarMensagem(m.group(3), m.group(1), m.group(2), m.group(4));
        } else {
            conversa.adicionarSistema(linha.startsWith("* ") ? linha.substring(2) : linha);
        }
        if (noFim || propria) {
            rolarParaOFim();
        }
    }

    private void rolarParaOFim() {
        JScrollBar barra = rolagem.getVerticalScrollBar();
        // duas voltas na fila de eventos: primeiro o layout novo, depois a rolagem
        SwingUtilities.invokeLater(() -> SwingUtilities.invokeLater(() -> barra.setValue(barra.getMaximum())));
    }

    // ------------------------------------------------------------ linhas de controle (#...)

    /** Linhas que começam com '#' não são mensagens: ver service.LinhasControle no servidor. */
    private void tratarControle(String linha) {
        int espaco = linha.indexOf(' ');
        String comando = espaco < 0 ? linha : linha.substring(0, espaco);
        String resto = espaco < 0 ? "" : linha.substring(espaco + 1);
        switch (comando) {
            case "#digitando" -> comecarDigitando(resto.isBlank() ? NOME_BOT : resto.trim());
            case "#parou" -> pararDigitando();
            case "#sugestoes" -> {
                List<Sugestao> novas = lerSugestoes(resto);
                montarPilulas(novas.isEmpty() ? SUGESTOES_INICIAIS : novas);
            }
            default -> { /* controle desconhecido (versão mais nova do servidor): ignora */ }
        }
    }

    /** "rotulo;texto;1|rotulo;texto;0" → lista (linhas malformadas são ignoradas). */
    static List<Sugestao> lerSugestoes(String dados) {
        List<Sugestao> lista = new ArrayList<>();
        for (String item : dados.split("\\|")) {
            String[] campos = item.split(";", -1);
            if (campos.length != 3 || campos[0].isBlank() || campos[1].isBlank()) {
                continue;
            }
            String rotulo = campos[0].length() > 22 ? campos[0].substring(0, 21) + "…" : campos[0];
            lista.add(new Sugestao(rotulo, campos[1], "1".equals(campos[2])));
            if (lista.size() == 5) {
                break;
            }
        }
        return lista;
    }

    /** Troca os botões de sugestão (mantendo o tema atual). */
    private void montarPilulas(List<Sugestao> sugestoes) {
        if (encerrado) {
            return;
        }
        painelSugestoes.removeAll();
        pilulas.clear();
        for (Sugestao s : sugestoes) {
            Widgets.Pilula p = new Widgets.Pilula(s.rotulo());
            p.setToolTipText(s.texto().trim());
            p.addActionListener(e -> usarSugestao(s));
            pilulas.add(p);
            painelSugestoes.add(p);
        }
        aplicarCoresDasPilulas();
        painelSugestoes.revalidate();
        painelSugestoes.repaint();
    }

    private void aplicarCoresDasPilulas() {
        for (Widgets.Pilula p : pilulas) {
            p.fundo = tema.chip();
            p.frente = tema.chipTexto();
        }
    }

    private void comecarDigitando(String nome) {
        if (encerrado) {
            return;
        }
        quemDigita = nome;
        digitandoDesde = System.currentTimeMillis();
        if (relogioDigitando == null) {
            relogioDigitando = new javax.swing.Timer(400, e -> animarDigitando());
        }
        relogioDigitando.start();
        animarDigitando();
    }

    private void animarDigitando() {
        if (quemDigita == null || System.currentTimeMillis() - digitandoDesde > LIMITE_DIGITANDO_MS) {
            pararDigitando();
            return;
        }
        pontos = (pontos + 1) % 4;
        subtitulo.setForeground(corDoSubtitulo());
        subtitulo.setText(quemDigita + " está digitando" + ".".repeat(pontos));
    }

    /** Destaque no \"digitando…\": âmbar no tema escuro; branco no claro (laranja some no cabeçalho índigo). */
    private Color corDoSubtitulo() {
        if (quemDigita == null) {
            return tema.subCabecalho();
        }
        return tema.escuro() ? tema.nomeBot() : tema.textoCabecalho();
    }

    private void pararDigitando() {
        if (relogioDigitando != null) {
            relogioDigitando.stop();
        }
        quemDigita = null;
        pontos = 0;
        subtitulo.setForeground(tema.subCabecalho());
        if (!encerrado && !nickAtual.isEmpty()) {
            subtitulo.setText("online como " + nickAtual);
        }
    }

    private void usarSugestao(Sugestao s) {
        if (s.enviar()) {
            enviarTexto(s.texto());
        } else {
            campo.setText(s.texto());
            campo.requestFocusInWindow();
            campo.setCaretPosition(campo.getText().length());
        }
    }

    private void enviar() {
        enviarTexto(campo.getText());
        campo.setText("");
    }

    private void enviarTexto(String texto) {
        if (encerrado || texto == null || texto.isBlank()) {
            return;
        }
        saida.println(texto.trim());
        if (saida.checkError()) {
            conexaoEncerrada();
        }
        campo.requestFocusInWindow();
    }

    private void conexaoEncerrada() {
        if (encerrado) {
            return;
        }
        encerrado = true;
        if (relogioDigitando != null) {
            relogioDigitando.stop();
        }
        quemDigita = null;
        subtitulo.setForeground(tema.subCabecalho());
        subtitulo.setText("desconectado");
        adicionar("* Conexão encerrada.");
        campo.setEnabled(false);
        botaoEnviar.setEnabled(false);
        pilulas.forEach(p -> p.setEnabled(false));
    }

    private void sair() {
        try {
            if (saida != null && !encerrado) {
                saida.println("/quit");
            }
            if (socket != null) {
                socket.close();
            }
        } catch (IOException e) {
            // saindo mesmo assim
        }
        janela.dispose();
        System.exit(0);
    }
}
