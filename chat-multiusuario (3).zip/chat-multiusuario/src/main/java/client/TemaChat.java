package client;

import java.awt.Color;

/** Paleta de cores do chat (Noite = roxo escuro, Aurora = lilás claro), com papel de parede em gradiente. */
record TemaChat(String nome, boolean escuro,
                Color fundo, Color cabecalho, Color textoCabecalho, Color subCabecalho,
                Color avatarFundo, Color avatarIcone,
                Color rodape, Color campo, Color textoCampo, Color dica,
                Color proprio, Color outro, Color texto, Color hora, Color horaProprio, Color tique,
                Color pilulaFundo, Color pilulaTexto,
                Color enviar, Color chip, Color chipTexto, Color nomeBot, Color[] coresNomes,
                Color papelTopo, Color papelBase, Color desenhoPapel) {

    static final TemaChat ESCURO = new TemaChat("Noite", true,
            c("#15112a"), c("#241b45"), c("#f1edff"), c("#a99ed6"),
            c("#7a5cff"), c("#f1edff"),
            c("#1d1638"), c("#2f2559"), c("#f1edff"), c("#9b90c8"),
            c("#6a46e5"), c("#2b2250"), c("#f1edff"), c("#a99ed6"), c("#d9cfff"), c("#ffd166"),
            c("#33285f"), c("#c9bfee"),
            c("#ff6b6b"), c("#33285f"), c("#d9d0f7"), c("#ffd166"),
            cores("#7dd3fc", "#f9a8d4", "#fdba74", "#c4b5fd", "#fde047", "#86efac", "#fca5a5", "#5eead4"),
            c("#1a1436"), c("#2a1a4d"), c("#ffffff"));

    static final TemaChat CLARO = new TemaChat("Aurora", false,
            c("#f4efff"), c("#5b3fd1"), c("#ffffff"), c("#ddd3ff"),
            c("#9d86f5"), c("#ffffff"),
            c("#ebe4ff"), c("#ffffff"), c("#1e1633"), c("#7b6f9c"),
            c("#d9ccff"), c("#ffffff"), c("#1e1633"), c("#7b6f9c"), c("#6a5a9e"), c("#ff7a59"),
            c("#fff0c2"), c("#5c4b8a"),
            c("#ff7a59"), c("#ffffff"), c("#5b3fd1"), c("#e8590c"),
            cores("#4263eb", "#d6336c", "#e8590c", "#7048e8", "#b08800", "#2b8a3e", "#c92a2a", "#0b7285"),
            c("#f7f2ff"), c("#e6dcff"), c("#5b3fd1"));

    private static Color c(String hex) {
        return Color.decode(hex);
    }

    private static Color[] cores(String... hexes) {
        Color[] r = new Color[hexes.length];
        for (int i = 0; i < hexes.length; i++) {
            r[i] = Color.decode(hexes[i]);
        }
        return r;
    }
}
