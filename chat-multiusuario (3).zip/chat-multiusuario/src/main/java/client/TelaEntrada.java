package client;

import javax.swing.BorderFactory;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

/** Tela de entrada no estilo do chat: pede o nickname (e mostra o erro, se o nome já estiver em uso). */
final class TelaEntrada {

    private static final Color VERDE = Color.decode("#5b3fd1");
    private static final Color VERDE_BOTAO = Color.decode("#ff7a59");
    private static final Color FUNDO = Color.decode("#f4efff");

    private TelaEntrada() {
    }

    /** Devolve o nickname digitado, ou null se a pessoa fechar a tela. erro pode ser null. */
    static String pedir(Component pai, String erro) {
        final String[] resultado = {null};
        JDialog dialogo = new JDialog((java.awt.Frame) null, "Entrar no chat", true);
        Widgets.CampoArredondado campo = new Widgets.CampoArredondado("Seu nickname");
        Widgets.Pilula entrar = new Widgets.Pilula("Entrar");
        dialogo.setContentPane(painel(campo, entrar, erro));

        Runnable confirmar = () -> {
            String texto = campo.getText().trim();
            if (!texto.isEmpty()) {
                resultado[0] = texto;
                dialogo.dispose();
            }
        };
        campo.addActionListener(e -> confirmar.run());
        entrar.addActionListener(e -> confirmar.run());
        dialogo.addWindowListener(new WindowAdapter() {
            @Override
            public void windowOpened(WindowEvent e) {
                campo.requestFocusInWindow();
            }
        });
        dialogo.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        dialogo.setResizable(false);
        dialogo.pack();
        dialogo.setLocationRelativeTo(pai);
        dialogo.setVisible(true);
        return resultado[0];
    }

    /** Monta o conteúdo (separado do JDialog para poder ser desenhado em testes). */
    static JPanel painel(Widgets.CampoArredondado campo, Widgets.Pilula entrar, String erro) {
        // faixa verde com avatar e nome do chat
        Widgets.Avatar avatar = new Widgets.Avatar();
        avatar.setPreferredSize(new Dimension(84, 84));
        avatar.fundo = Color.decode("#9d86f5");
        avatar.icone = Color.WHITE;
        JLabel titulo = rotulo("Chat Multiusuário", 20, Font.BOLD, Color.WHITE);
        JLabel sub = rotulo("Converse com todo mundo e com o ChatBot", 12, Font.PLAIN, Color.decode("#ddd3ff"));

        JPanel faixa = new JPanel(new GridBagLayout());
        faixa.setBackground(VERDE);
        faixa.setBorder(new EmptyBorder(26, 20, 22, 20));
        GridBagConstraints c = new GridBagConstraints();
        c.gridx = 0;
        c.gridy = 0;
        c.insets = new java.awt.Insets(0, 0, 12, 0);
        faixa.add(avatar, c);
        c.gridy = 1;
        c.insets = new java.awt.Insets(0, 0, 4, 0);
        faixa.add(titulo, c);
        c.gridy = 2;
        c.insets = new java.awt.Insets(0, 0, 0, 0);
        faixa.add(sub, c);

        // corpo claro com campo e botão
        campo.fundoCampo = Color.WHITE;
        campo.corDica = Color.decode("#7b6f9c");
        campo.setForeground(Color.decode("#1e1633"));
        campo.setBorder(new EmptyBorder(13, 20, 13, 20));
        campo.setPreferredSize(new Dimension(300, 48));

        entrar.fundo = VERDE_BOTAO;
        entrar.frente = Color.WHITE;
        entrar.setFont(Fontes.de(Font.BOLD, 14));
        entrar.setPreferredSize(new Dimension(300, 46));

        JLabel dica = rotulo(erro == null ? "Escolha um nome para aparecer no chat" : erro, 12, Font.PLAIN,
                erro == null ? Color.decode("#7b6f9c") : Color.decode("#c92a2a"));
        dica.setHorizontalAlignment(SwingConstants.CENTER);
        dica.setPreferredSize(new Dimension(300, 34));

        JPanel corpo = new JPanel(new GridBagLayout());
        corpo.setBackground(FUNDO);
        corpo.setBorder(new EmptyBorder(22, 24, 26, 24));
        GridBagConstraints b = new GridBagConstraints();
        b.gridx = 0;
        b.gridy = 0;
        corpo.add(dica, b);
        b.gridy = 1;
        b.insets = new java.awt.Insets(4, 0, 14, 0);
        corpo.add(campo, b);
        b.gridy = 2;
        b.insets = new java.awt.Insets(0, 0, 0, 0);
        corpo.add(entrar, b);

        JPanel raiz = new JPanel(new BorderLayout());
        raiz.add(faixa, BorderLayout.NORTH);
        raiz.add(corpo, BorderLayout.CENTER);
        raiz.setBorder(BorderFactory.createEmptyBorder());
        return raiz;
    }

    private static JLabel rotulo(String texto, int tamanho, int estilo, Color cor) {
        JLabel l = new JLabel(texto);
        l.setFont(Fontes.de(estilo, tamanho));
        l.setForeground(cor);
        return l;
    }
}
