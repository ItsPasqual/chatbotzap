package client;

import javax.swing.JPanel;
import javax.swing.JViewport;
import javax.swing.Scrollable;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.GradientPaint;
import java.awt.Graphics2D;
import java.awt.Polygon;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.event.ComponentAdapter;
import java.awt.event.ComponentEvent;
import java.awt.geom.AffineTransform;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Path2D;
import java.awt.geom.RoundRectangle2D;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/**
 * Lista de mensagens desenhada à mão (balões estilo WhatsApp). Só é usada na thread do Swing.
 * Medidas dependem da largura: são recalculadas quando a janela muda de tamanho ou chega mensagem.
 */
final class ConversaPanel extends JPanel implements Scrollable {

    private enum Tipo { MENSAGEM, SISTEMA, DIA }

    private static final class Item {
        final Tipo tipo;
        final String nome;
        final String hora;
        final String texto;
        // calculados em recalcular()
        List<String> linhas = List.of();
        int x, y, w, h;
        boolean proprio, bot, primeiro, mostraNome, horaNaLinha;

        Item(Tipo tipo, String nome, String hora, String texto) {
            this.tipo = tipo;
            this.nome = nome;
            this.hora = hora;
            this.texto = texto;
        }
    }

    private static final Font FONTE_TEXTO = Fontes.de(Font.PLAIN, 14);
    private static final Font FONTE_NOME = Fontes.de(Font.BOLD, 12);
    private static final Font FONTE_HORA = Fontes.de(Font.PLAIN, 11);
    private static final Font FONTE_SISTEMA = Fontes.de(Font.PLAIN, 12);
    private static final Font FONTE_DIA = Fontes.de(Font.BOLD, 11);

    private static final int PAD_X = 10;
    private static final int PAD_Y = 6;
    private static final int MARGEM = 14;
    private static final int LARGURA_TIQUE = 16;

    private final List<Item> itens = new ArrayList<>();
    private TemaChat tema = TemaChat.ESCURO;
    private String nick = "";
    private String ultimaData;

    private int larguraCalculada = -1;
    private int alturaTotal = 0;
    private int alturaAnunciada = -1;
    private boolean sujo = true;

    ConversaPanel() {
        setOpaque(true);
        addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                sujo = true;
                revalidate();
            }
        });
    }

    // ------------------------------------------------------------ API

    void setTema(TemaChat novo) {
        this.tema = novo;
        repaint();
    }

    void setNick(String novo) {
        this.nick = novo == null ? "" : novo;
        sujo = true;
        revalidate();
        repaint();
    }

    /** data no formato dd/MM e hora HH:mm, como vêm do servidor. */
    void adicionarMensagem(String nome, String data, String hora, String texto) {
        if (!data.equals(ultimaData)) {
            itens.add(new Item(Tipo.DIA, "", "", rotuloDia(data)));
            ultimaData = data;
        }
        itens.add(new Item(Tipo.MENSAGEM, nome, hora, texto));
        mudou();
    }

    void adicionarSistema(String texto) {
        itens.add(new Item(Tipo.SISTEMA, "", "", texto));
        mudou();
    }

    private void mudou() {
        sujo = true;
        revalidate();
        repaint();
    }

    private static String rotuloDia(String data) {
        DateTimeFormatter f = DateTimeFormatter.ofPattern("dd/MM");
        LocalDate hoje = LocalDate.now();
        if (data.equals(hoje.format(f))) {
            return "HOJE";
        }
        if (data.equals(hoje.minusDays(1).format(f))) {
            return "ONTEM";
        }
        return data;
    }

    // ------------------------------------------------------------ medidas

    @Override
    public Dimension getPreferredSize() {
        int w = larguraDisponivel();
        recalcular(w);
        alturaAnunciada = alturaTotal;
        return new Dimension(w, alturaTotal);
    }

    private int larguraDisponivel() {
        Container pai = getParent();
        int w = pai instanceof JViewport ? pai.getWidth() : getWidth();
        return Math.max(w, 240);
    }

    private void recalcular(int w) {
        if (!sujo && w == larguraCalculada) {
            return;
        }
        FontMetrics fmTexto = getFontMetrics(FONTE_TEXTO);
        FontMetrics fmNome = getFontMetrics(FONTE_NOME);
        FontMetrics fmHora = getFontMetrics(FONTE_HORA);
        FontMetrics fmSis = getFontMetrics(FONTE_SISTEMA);
        FontMetrics fmDia = getFontMetrics(FONTE_DIA);

        int maxBalao = Math.max(150, Math.min((int) (w * 0.74), 560));
        int y = 10;
        Item anterior = null;
        for (Item it : itens) {
            switch (it.tipo) {
                case MENSAGEM -> {
                    it.proprio = it.nome.equalsIgnoreCase(nick);
                    it.bot = it.nome.equalsIgnoreCase(ClienteChatGui.NOME_BOT);
                    it.primeiro = !(anterior != null && anterior.tipo == Tipo.MENSAGEM
                            && anterior.nome.equalsIgnoreCase(it.nome));
                    it.mostraNome = it.primeiro && !it.proprio;

                    int maxTexto = maxBalao - 2 * PAD_X;
                    it.linhas = quebrar(it.texto, fmTexto, maxTexto);
                    int larguraTexto = 0;
                    for (String l : it.linhas) {
                        larguraTexto = Math.max(larguraTexto, fmTexto.stringWidth(l));
                    }
                    int ultima = fmTexto.stringWidth(it.linhas.get(it.linhas.size() - 1));
                    int larguraHora = fmHora.stringWidth(it.hora) + (it.proprio ? LARGURA_TIQUE + 3 : 0);
                    it.horaNaLinha = ultima + 12 + larguraHora <= maxTexto;
                    int larguraNome = it.mostraNome ? fmNome.stringWidth(rotuloNome(it)) : 0;

                    int conteudo = Math.max(Math.max(larguraTexto, larguraNome),
                            it.horaNaLinha ? ultima + 12 + larguraHora : larguraHora);
                    conteudo = Math.min(conteudo, maxTexto);

                    it.w = conteudo + 2 * PAD_X;
                    it.h = PAD_Y * 2 + (it.mostraNome ? fmNome.getHeight() + 2 : 0)
                            + it.linhas.size() * fmTexto.getHeight()
                            + (it.horaNaLinha ? 0 : fmHora.getHeight());
                    it.x = it.proprio ? w - MARGEM - 6 - it.w : MARGEM + 6;
                    y += anterior == null ? 0 : it.primeiro ? 9 : 2;
                }
                case SISTEMA, DIA -> {
                    boolean dia = it.tipo == Tipo.DIA;
                    FontMetrics fm = dia ? fmDia : fmSis;
                    it.linhas = quebrar(it.texto, fm, (int) (w * 0.8) - 28);
                    int lw = 0;
                    for (String l : it.linhas) {
                        lw = Math.max(lw, fm.stringWidth(l));
                    }
                    it.w = lw + 28;
                    it.h = it.linhas.size() * fm.getHeight() + 10;
                    it.x = (w - it.w) / 2;
                    y += anterior == null ? 0 : 10;
                }
            }
            it.y = y;
            y += it.h;
            anterior = it;
        }
        alturaTotal = y + 12;
        larguraCalculada = w;
        sujo = false;
    }

    /** Quebra por palavras; palavras maiores que a linha são cortadas por caractere. */
    static List<String> quebrar(String texto, FontMetrics fm, int max) {
        List<String> linhas = new ArrayList<>();
        StringBuilder atual = new StringBuilder();
        for (String palavra : texto.split(" ")) {
            if (fm.stringWidth(palavra) > max) {
                if (atual.length() > 0) {
                    linhas.add(atual.toString());
                    atual.setLength(0);
                }
                StringBuilder pedaco = new StringBuilder();
                for (char c : palavra.toCharArray()) {
                    if (fm.stringWidth(pedaco.toString() + c) > max && pedaco.length() > 0) {
                        linhas.add(pedaco.toString());
                        pedaco.setLength(0);
                    }
                    pedaco.append(c);
                }
                atual.append(pedaco);
                continue;
            }
            String candidata = atual.length() == 0 ? palavra : atual + " " + palavra;
            if (fm.stringWidth(candidata) <= max) {
                atual.setLength(0);
                atual.append(candidata);
            } else {
                linhas.add(atual.toString());
                atual.setLength(0);
                atual.append(palavra);
            }
        }
        if (atual.length() > 0 || linhas.isEmpty()) {
            linhas.add(atual.toString());
        }
        return linhas;
    }

    private static String rotuloNome(Item it) {
        return it.bot ? it.nome + " · bot" : it.nome;
    }

    // ------------------------------------------------------------ desenho

    @Override
    protected void paintComponent(Graphics g0) {
        Graphics2D g = (Graphics2D) g0.create();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        desenharPapelDeParede(g);

        recalcular(getWidth());
        if (alturaTotal != alturaAnunciada) {
            SwingUtilities.invokeLater(this::revalidate);
        }
        Rectangle clip = g.getClipBounds() != null ? g.getClipBounds() : new Rectangle(getSize());
        for (Item it : itens) {
            if (it.y + it.h + 10 < clip.y || it.y - 10 > clip.y + clip.height) {
                continue;
            }
            if (it.tipo == Tipo.MENSAGEM) {
                desenharMensagem(g, it);
            } else {
                desenharPilula(g, it);
            }
        }
        g.dispose();
    }


    // ------------------------------------------------------------ papel de parede

    private static final int LADO_PAPEL = 84;

    /**
     * Fundo em gradiente com rabiscos (estrelas, círculos, ondas...) desenhados por código.
     * Fica parado na tela: as mensagens rolam por cima, como um papel de parede.
     */
    private void desenharPapelDeParede(Graphics2D g) {
        Rectangle v = getVisibleRect();
        if (v.isEmpty()) {
            v = new Rectangle(getSize());
        }
        g.setPaint(new GradientPaint(0, v.y, tema.papelTopo(), 0, v.y + v.height, tema.papelBase()));
        g.fillRect(v.x, v.y, v.width, v.height);

        Color cor = tema.desenhoPapel();
        g.setColor(new Color(cor.getRed(), cor.getGreen(), cor.getBlue(), tema.escuro() ? 22 : 30));
        g.setStroke(new BasicStroke(1.6f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        AffineTransform original = g.getTransform();
        for (int linha = -1; linha * LADO_PAPEL <= v.height; linha++) {
            for (int col = -1; col * LADO_PAPEL <= v.width; col++) {
                int deslocamento = Math.floorMod(linha, 2) == 0 ? 0 : LADO_PAPEL / 2;
                int cx = v.x + col * LADO_PAPEL + deslocamento + LADO_PAPEL / 2;
                int cy = v.y + linha * LADO_PAPEL + LADO_PAPEL / 2;
                int sorteio = Math.floorMod(col * 7 + linha * 13 + col * linha, 5);
                g.setTransform(original);
                g.translate(cx, cy);
                g.rotate(Math.toRadians(Math.floorMod(col * 37 + linha * 53, 60) - 30));
                desenharRabisco(g, sorteio);
            }
        }
        g.setTransform(original);
        g.setStroke(new BasicStroke(1f));
    }

    private static void desenharRabisco(Graphics2D g, int tipo) {
        switch (tipo) {
            case 0 -> g.draw(new Ellipse2D.Float(-9, -9, 18, 18));
            case 1 -> { // estrela de 5 pontas
                Path2D estrela = new Path2D.Float();
                for (int i = 0; i < 10; i++) {
                    double raio = i % 2 == 0 ? 11 : 4.5;
                    double a = -Math.PI / 2 + i * Math.PI / 5;
                    if (i == 0) {
                        estrela.moveTo(Math.cos(a) * raio, Math.sin(a) * raio);
                    } else {
                        estrela.lineTo(Math.cos(a) * raio, Math.sin(a) * raio);
                    }
                }
                estrela.closePath();
                g.draw(estrela);
            }
            case 2 -> { // mais
                g.drawLine(-8, 0, 8, 0);
                g.drawLine(0, -8, 0, 8);
            }
            case 3 -> { // onda
                Path2D onda = new Path2D.Float();
                onda.moveTo(-14, 0);
                onda.curveTo(-9, -9, -4, -9, 0, 0);
                onda.curveTo(4, 9, 9, 9, 14, 0);
                g.draw(onda);
            }
            default -> { // triângulo
                Path2D tri = new Path2D.Float();
                tri.moveTo(0, -9);
                tri.lineTo(9, 7);
                tri.lineTo(-9, 7);
                tri.closePath();
                g.draw(tri);
            }
        }
    }

    private void desenharMensagem(Graphics2D g, Item it) {
        int x = it.x, y = it.y, w = it.w, h = it.h;
        Color fundo = it.proprio ? tema.proprio() : tema.outro();

        g.setColor(new Color(0, 0, 0, tema.escuro() ? 70 : 28));
        g.fill(new RoundRectangle2D.Float(x, y + 1, w, h, 16, 16));
        g.setColor(fundo);
        g.fill(new RoundRectangle2D.Float(x, y, w, h, 16, 16));
        if (it.primeiro) { // "rabinho" no canto superior
            Polygon cauda = new Polygon();
            if (it.proprio) {
                g.fillRect(x + w - 8, y, 8, 8);
                cauda.addPoint(x + w - 2, y);
                cauda.addPoint(x + w + 7, y);
                cauda.addPoint(x + w - 2, y + 9);
            } else {
                g.fillRect(x, y, 8, 8);
                cauda.addPoint(x + 2, y);
                cauda.addPoint(x - 7, y);
                cauda.addPoint(x + 2, y + 9);
            }
            g.fillPolygon(cauda);
        }

        FontMetrics fmNome = g.getFontMetrics(FONTE_NOME);
        FontMetrics fmTexto = g.getFontMetrics(FONTE_TEXTO);
        FontMetrics fmHora = g.getFontMetrics(FONTE_HORA);
        int topo = y + PAD_Y;

        if (it.mostraNome) {
            g.setFont(FONTE_NOME);
            g.setColor(it.bot ? tema.nomeBot() : corDoNome(it.nome));
            g.drawString(rotuloNome(it), x + PAD_X, topo + fmNome.getAscent());
            topo += fmNome.getHeight() + 2;
        }
        g.setFont(FONTE_TEXTO);
        g.setColor(tema.texto());
        int lh = fmTexto.getHeight();
        for (int i = 0; i < it.linhas.size(); i++) {
            g.drawString(it.linhas.get(i), x + PAD_X, topo + i * lh + fmTexto.getAscent());
        }

        int base = it.horaNaLinha
                ? topo + (it.linhas.size() - 1) * lh + fmTexto.getAscent()
                : topo + it.linhas.size() * lh + fmHora.getAscent() - 1;
        int direita = x + w - PAD_X;
        if (it.proprio) {
            desenharTique(g, direita - 13, base, tema.tique());
            direita -= LARGURA_TIQUE + 3;
        }
        g.setFont(FONTE_HORA);
        g.setColor(it.proprio ? tema.horaProprio() : tema.hora());
        g.drawString(it.hora, direita - fmHora.stringWidth(it.hora), base);
    }

    /** Dois "vistos" (✓✓) desenhados com linhas, para não depender de fonte. */
    private static void desenharTique(Graphics2D g, int x, int base, Color cor) {
        int topo = base - 8;
        g.setColor(cor);
        g.setStroke(new BasicStroke(1.5f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        g.drawPolyline(new int[]{x, x + 3, x + 8}, new int[]{topo + 5, topo + 8, topo + 1}, 3);
        g.drawPolyline(new int[]{x + 4, x + 7, x + 12}, new int[]{topo + 5, topo + 8, topo + 1}, 3);
        g.setStroke(new BasicStroke(1f));
    }

    private void desenharPilula(Graphics2D g, Item it) {
        boolean dia = it.tipo == Tipo.DIA;
        Font fonte = dia ? FONTE_DIA : FONTE_SISTEMA;
        FontMetrics fm = g.getFontMetrics(fonte);
        g.setColor(new Color(0, 0, 0, tema.escuro() ? 60 : 22));
        g.fill(new RoundRectangle2D.Float(it.x, it.y + 1, it.w, it.h, 16, 16));
        g.setColor(tema.pilulaFundo());
        g.fill(new RoundRectangle2D.Float(it.x, it.y, it.w, it.h, 16, 16));
        g.setFont(fonte);
        g.setColor(tema.pilulaTexto());
        for (int i = 0; i < it.linhas.size(); i++) {
            String l = it.linhas.get(i);
            g.drawString(l, it.x + (it.w - fm.stringWidth(l)) / 2, it.y + 5 + i * fm.getHeight() + fm.getAscent());
        }
    }

    private Color corDoNome(String nome) {
        Color[] cores = tema.coresNomes();
        return cores[Math.floorMod(nome.toLowerCase().hashCode(), cores.length)];
    }

    // ------------------------------------------------------------ Scrollable

    @Override
    public Dimension getPreferredScrollableViewportSize() {
        return new Dimension(400, 500);
    }

    @Override
    public int getScrollableUnitIncrement(Rectangle visible, int orientation, int direction) {
        return 28;
    }

    @Override
    public int getScrollableBlockIncrement(Rectangle visible, int orientation, int direction) {
        return orientation == SwingConstants.VERTICAL ? visible.height - 40 : visible.width;
    }

    @Override
    public boolean getScrollableTracksViewportWidth() {
        return true;
    }

    @Override
    public boolean getScrollableTracksViewportHeight() {
        // conversa curta: ocupa a janela inteira, para o papel de parede aparecer até embaixo
        return getParent() instanceof JViewport vp && vp.getHeight() > getPreferredSize().height;
    }
}
