package client;

import java.awt.Font;
import java.awt.GraphicsEnvironment;
import java.util.Set;

/** Escolhe a primeira fonte arredondada/amigável instalada (nada de Segoe UI, para fugir do visual do WhatsApp). */
final class Fontes {

    static final String FAMILIA = escolher();

    private Fontes() {
    }

    static Font de(int estilo, int tamanho) {
        return new Font(FAMILIA, estilo, tamanho);
    }

    private static String escolher() {
        Set<String> instaladas = Set.of(GraphicsEnvironment.getLocalGraphicsEnvironment()
                .getAvailableFontFamilyNames());
        for (String candidata : new String[]{"Nunito", "Trebuchet MS", "Verdana", "Ubuntu", "Noto Sans", "Tahoma"}) {
            if (instaladas.contains(candidata)) {
                return candidata;
            }
        }
        return Font.SANS_SERIF;
    }
}
