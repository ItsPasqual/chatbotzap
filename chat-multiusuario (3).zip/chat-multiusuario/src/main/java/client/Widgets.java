package client;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JScrollBar;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.plaf.basic.BasicScrollBarUI;
import java.awt.Insets;
import java.awt.FlowLayout;
import java.awt.Container;
import java.awt.Component;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.Area;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;
import java.awt.geom.RoundRectangle2D;

/** Componentes pequenos desenhados à mão para o visual do chat. */
final class Widgets {

    private Widgets() {
    }

    static Graphics2D suave(Graphics g) {
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        return g2;
    }

    /** Avatar redondo com silhueta de pessoa. */
    static final class Avatar extends JComponent {
        Color fundo = Color.GRAY;
        Color icone = Color.WHITE;

        Avatar() {
            setPreferredSize(new Dimension(42, 42));
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = suave(g);
            int w = getWidth(), h = getHeight(), cx = w / 2;
            double k = Math.min(w, h) / 42.0; // tudo proporcional ao tamanho do avatar
            g2.setColor(fundo);
            g2.fillOval(0, 0, w, h);
            g2.setColor(icone);
            g2.fill(new Ellipse2D.Double(cx - 6 * k, h / 2.0 - 12 * k, 12 * k, 12 * k));
            Shape antes = g2.getClip();
            g2.setClip(new Ellipse2D.Float(0, 0, w, h));
            g2.fill(new Ellipse2D.Double(cx - 13 * k, h / 2.0 + 2 * k, 26 * k, 24 * k));
            g2.setClip(antes);
            g2.dispose();
        }
    }

    /** Campo de texto em forma de pílula, com texto de dica. */
    static final class CampoArredondado extends JTextField {
        Color fundoCampo = Color.WHITE;
        Color corDica = Color.GRAY;
        private final String dica;

        CampoArredondado(String dica) {
            this.dica = dica;
            setOpaque(false);
            setBorder(new EmptyBorder(12, 20, 12, 20));
            setFont(Fontes.de(Font.PLAIN, 15));
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = suave(g);
            g2.setColor(fundoCampo);
            g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), getHeight(), getHeight()));
            g2.dispose();
            super.paintComponent(g);
            if (getText().isEmpty()) {
                Graphics2D t = suave(g);
                t.setFont(getFont());
                t.setColor(corDica);
                FontMetrics fm = t.getFontMetrics();
                t.drawString(dica, getInsets().left, (getHeight() - fm.getHeight()) / 2 + fm.getAscent());
                t.dispose();
            }
        }
    }

    enum Icone { ENVIAR, SOL, LUA }

    /** Botão redondo com ícone desenhado (enviar, sol, lua). */
    static final class BotaoIcone extends JButton {
        Icone icone;
        Color fundo = new Color(0, 0, 0, 0);
        Color frente = Color.WHITE;
        private boolean sobre;

        BotaoIcone(Icone icone, int tamanho) {
            this.icone = icone;
            setPreferredSize(new Dimension(tamanho, tamanho));
            setContentAreaFilled(false);
            setBorderPainted(false);
            setFocusPainted(false);
            setOpaque(false);
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    sobre = true;
                    repaint();
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    sobre = false;
                    repaint();
                }
            });
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = suave(g);
            int w = getWidth(), h = getHeight();
            Color bg = isEnabled() ? fundo : new Color(120, 130, 135);
            if (bg.getAlpha() > 0 || sobre) {
                g2.setColor(sobre && isEnabled() && bg.getAlpha() == 0 ? new Color(255, 255, 255, 40) : bg);
                g2.fillOval(0, 0, w, h);
            }
            g2.setColor(frente);
            g2.translate(w / 2.0, h / 2.0);
            switch (icone) {
                case ENVIAR -> {
                    g2.fillPolygon(new int[]{-8, 9, -8, -4}, new int[]{-8, 0, 8, 0}, 4);
                }
                case SOL -> {
                    g2.fill(new Ellipse2D.Float(-4.5f, -4.5f, 9, 9));
                    g2.setStroke(new BasicStroke(1.8f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                    for (int i = 0; i < 8; i++) {
                        double a = i * Math.PI / 4;
                        g2.draw(new Line2D.Double(Math.cos(a) * 7.5, Math.sin(a) * 7.5,
                                Math.cos(a) * 10, Math.sin(a) * 10));
                    }
                }
                case LUA -> {
                    Area lua = new Area(new Ellipse2D.Float(-8, -8, 16, 16));
                    lua.subtract(new Area(new Ellipse2D.Float(-3, -11, 15, 15)));
                    g2.fill(lua);
                }
            }
            g2.dispose();
        }
    }

    /** Botão em forma de pílula (sugestões rápidas). */
    /** FlowLayout que quebra linha de verdade: a altura preferida cresce quando os botões não cabem. */
    static final class WrapLayout extends FlowLayout {
        WrapLayout(int alinhamento, int hgap, int vgap) {
            super(alinhamento, hgap, vgap);
        }

        @Override
        public Dimension preferredLayoutSize(Container alvo) {
            return medir(alvo, true);
        }

        @Override
        public Dimension minimumLayoutSize(Container alvo) {
            Dimension d = medir(alvo, false);
            d.width -= getHgap() + 1;
            return d;
        }

        private Dimension medir(Container alvo, boolean preferido) {
            synchronized (alvo.getTreeLock()) {
                Container pai = alvo.getParent();
                int largura = pai != null && pai.getWidth() > 0 ? pai.getWidth() : alvo.getWidth();
                if (largura <= 0) {
                    largura = Integer.MAX_VALUE;
                }
                Insets bordas = alvo.getInsets();
                int horizontal = getHgap() * 2 + bordas.left + bordas.right;
                int util = largura - horizontal;
                Dimension total = new Dimension(0, 0);
                int larguraLinha = 0;
                int alturaLinha = 0;
                for (Component c : alvo.getComponents()) {
                    if (!c.isVisible()) {
                        continue;
                    }
                    Dimension d = preferido ? c.getPreferredSize() : c.getMinimumSize();
                    if (larguraLinha > 0 && larguraLinha + getHgap() + d.width > util) {
                        fecharLinha(total, larguraLinha, alturaLinha);
                        larguraLinha = 0;
                        alturaLinha = 0;
                    }
                    larguraLinha += (larguraLinha > 0 ? getHgap() : 0) + d.width;
                    alturaLinha = Math.max(alturaLinha, d.height);
                }
                fecharLinha(total, larguraLinha, alturaLinha);
                total.width += horizontal;
                total.height += bordas.top + bordas.bottom + getVgap() * 2;
                return total;
            }
        }

        private void fecharLinha(Dimension total, int larguraLinha, int alturaLinha) {
            total.width = Math.max(total.width, larguraLinha);
            if (total.height > 0) {
                total.height += getVgap();
            }
            total.height += alturaLinha;
        }
    }

    static final class Pilula extends JButton {
        Color fundo = Color.LIGHT_GRAY;
        Color frente = Color.BLACK;
        private boolean sobre;

        Pilula(String texto) {
            super(texto);
            setFont(Fontes.de(Font.PLAIN, 12));
            setContentAreaFilled(false);
            setBorderPainted(false);
            setFocusPainted(false);
            setOpaque(false);
            setBorder(new EmptyBorder(6, 13, 6, 13));
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    sobre = true;
                    repaint();
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    sobre = false;
                    repaint();
                }
            });
        }

        @Override
        public Dimension getPreferredSize() {
            if (isPreferredSizeSet()) {
                return super.getPreferredSize();
            }
            FontMetrics fm = getFontMetrics(getFont());
            return new Dimension(fm.stringWidth(getText()) + 26, fm.getHeight() + 12);
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = suave(g);
            g2.setColor(sobre ? fundo.brighter() : fundo);
            g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), getHeight(), getHeight()));
            g2.setFont(getFont());
            g2.setColor(isEnabled() ? frente : frente.darker());
            FontMetrics fm = g2.getFontMetrics();
            g2.drawString(getText(), (getWidth() - fm.stringWidth(getText())) / 2,
                    (getHeight() - fm.getHeight()) / 2 + fm.getAscent());
            g2.dispose();
        }
    }

    /** Barra de rolagem fina e arredondada. */
    static final class ScrollFino extends BasicScrollBarUI {
        private final Color cor;

        ScrollFino(Color cor) {
            this.cor = cor;
        }

        static void aplicar(JScrollBar barra, Color cor) {
            barra.setUI(new ScrollFino(cor));
            barra.setPreferredSize(new Dimension(9, 0));
            barra.setUnitIncrement(28);
            barra.setOpaque(false);
        }

        private static JButton vazio() {
            JButton b = new JButton();
            b.setPreferredSize(new Dimension(0, 0));
            return b;
        }

        @Override
        protected JButton createDecreaseButton(int orientation) {
            return vazio();
        }

        @Override
        protected JButton createIncreaseButton(int orientation) {
            return vazio();
        }

        @Override
        protected void paintTrack(Graphics g, JComponent c, Rectangle r) {
            // trilho transparente
        }

        @Override
        protected void paintThumb(Graphics g, JComponent c, Rectangle r) {
            if (r.isEmpty()) {
                return;
            }
            Graphics2D g2 = suave(g);
            g2.setColor(cor);
            g2.fill(new RoundRectangle2D.Float(r.x + 1, r.y, r.width - 2, r.height, 8, 8));
            g2.dispose();
        }
    }
}
