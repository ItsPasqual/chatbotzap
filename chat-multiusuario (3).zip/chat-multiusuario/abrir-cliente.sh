#!/bin/sh
# Cada execução abre uma janela de chat nova. Outra máquina: ./abrir-cliente.sh IP_DO_SERVIDOR
mvn -q compile exec:java -Dexec.mainClass=client.ClienteChatGui -Dexec.args="${1:-localhost} 5000" &
