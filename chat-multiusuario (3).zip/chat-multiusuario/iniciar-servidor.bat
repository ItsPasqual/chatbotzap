@echo off
chcp 65001 >nul
mvn compile exec:java "-Dexec.mainClass=server.Servidor"
