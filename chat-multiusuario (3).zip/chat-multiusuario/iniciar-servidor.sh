#!/bin/sh
mvn compile exec:java -Dexec.mainClass=server.Servidor
